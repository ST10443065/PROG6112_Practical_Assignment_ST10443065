/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.demo.studentmanagement;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author bonolodinkoanyane
 */
public class StudentManagement {
    
    // the below arrayList will store student objects as the user creates them, and they will be retrived when a report is made, or the student number is searched
    private static ArrayList<student> students = new ArrayList<>(); 

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
    /*part of this method below was taken from JAVA Programming Tenth Edition
      Using the switch case (page 183-184 chapter 5)
      Joyce Farrell
    */
        while (running) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1 -> student.saveStudent(scanner);
                case 2 -> student.searchStudent(scanner);
                case 3 -> student.deleteStudent(scanner);
                case 4 -> student.studentReport();
                case 5 -> student.exitApplication();
                default -> System.out.println("Invalid choice. Please select a valid option from the selection.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("1. Capture Student");
        System.out.println("2. Search Student");
        System.out.println("3. Delete Student");
        System.out.println("4. View Student Report");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    
}
  