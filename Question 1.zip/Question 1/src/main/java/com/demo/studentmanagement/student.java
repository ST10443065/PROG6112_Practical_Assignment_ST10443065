/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.studentmanagement;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author bonolodinkoanyane
 */


import java.util.ArrayList;
import java.util.Scanner;

public class student {
    
    static ArrayList<student> students = new ArrayList<>();
    private String studentID;
    private String name;
    private int age;
    private String email;
    private String course;

    
    public student(String studentID, String name, String surname, int age, String email, String course) {
        
        this.studentID = studentID;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    
    // Method to save a student
    public static void saveStudent(Scanner scanner) {
        System.out.print("Enter Student ID: ");
        String studentID = scanner.nextLine();

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter Surname: ");
        String surname = scanner.nextLine();

        int age = 0;
        while (true) {
            System.out.print("Enter Age: ");
            if (scanner.hasNextInt()) {
                age = scanner.nextInt();
                scanner.nextLine();  
                if (age >= 16) {
                    break;
                } 
                else {
                    System.out.println("Users age should be 16 and older");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();  
            }
        }

        System.out.print("Enter Email: ");
        String email = scanner.nextLine();

        System.out.print("Enter Course: ");
        String course = scanner.nextLine();

        // this code snippet below creates a new student object and adds it to the arraylist
        //
        student newStudent = new student(studentID, name, surname, age, email, course);
        students.add(newStudent);

        System.out.println("Student details have been successfully saved.");
    }

    // Method searches for a student using the the student number supplied by the user
    public static void searchStudent(Scanner scanner) {
        System.out.print("Enter Student ID to search: ");
        String studentID = scanner.nextLine();

        student foundStudent = null;
        for (student student : students) {
            if (studentID.equals(studentID)) {
                foundStudent = student;
                break;
            }
        }
        //this if statement below was taken from ChatGPT
        // on tuesday 02 September 2024
        if (foundStudent != null) {
            System.out.println("Student found:");
            foundStudent.displayStudentInfo();
        } 
        else {
            System.out.println("Error: Student with ID " + studentID + " cannot be located.");
        }
    }

    /*
        This method below makes use of an if statement chack if the entered student number matches any recordds in the memory, if found it then displays 
        a confirmation message for the user which they must accept with yes/no to proceed
    */
    public static void deleteStudent(Scanner scanner) {
        System.out.print("Enter Student ID to delete: ");
        String studentID = scanner.nextLine();

        student foundStudent = null;
        for (student student : students) {
            if (studentID.equals(studentID)) {
                foundStudent = student;
                break;
            }
        }

        if (foundStudent != null) {
            System.out.println("Student found:");
            foundStudent.displayStudentInfo();
            System.out.print("Are you sure you want to delete this student?" +studentID+" (yes/no): ");
            String confirmation = scanner.nextLine().trim().toLowerCase();

            if (confirmation.equals("yes")) {
                students.remove(foundStudent);
                System.out.println("Student with ID " + studentID + " has been successfully deleted.");
            } 
            else {
                System.out.println("Deletion cancelled.");
            }
        } 
        else {
            System.out.println("Error: Student ID " + studentID + " cannot be located.");
        }
    }
    
    public static boolean isValidAge(int age) {
    return age >= 16;
}

    // Below method generates a student report/summary of all the registered students stored in the memory
    public static void studentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (student student : students) {
                student.displayStudentInfo();
                System.out.println("---------------------------");
            }
        }
    }

    // This method displays individual student details rather than a whole report. The details are accessed via student number  
    public void displayStudentInfo() {
        System.out.println("Student ID: " + studentID);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Email: " + email);
        System.out.println("Course: " + course);
    }
    
    public static void exitApplication() {
        System.exit(0);
    }
}