/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.demo.studentmanagement;

import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bonolodinkoanyane
 */
public class studentIT {
    
    public studentIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getStudentID method, of class student.
     */
    @Test
    public void testGetStudentID() {
        System.out.println("getStudentID");
        student instance = null;
        String expResult = "";
        String result = instance.getStudentID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class student.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        student instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAge method, of class student.
     */
    @Test
    public void testGetAge() {
        System.out.println("getAge");
        student instance = null;
        int expResult = 0;
        int result = instance.getAge();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEmail method, of class student.
     */
    @Test
    public void testGetEmail() {
        System.out.println("getEmail");
        student instance = null;
        String expResult = "";
        String result = instance.getEmail();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCourse method, of class student.
     */
    @Test
    public void testGetCourse() {
        System.out.println("getCourse");
        student instance = null;
        String expResult = "";
        String result = instance.getCourse();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of saveStudent method, of class student.
     */
    @Test
    public void testSaveStudent() {
       
        
        assertEquals(1, student.students.size());
        student savedStudent = student.students.get(0);
        assertEquals("001", savedStudent.getStudentID());
        assertEquals("John Doe", savedStudent.getName());
        assertEquals(18, savedStudent.getAge());
        assertEquals("john.doe@example.com", savedStudent.getEmail());
        assertEquals("Computer Science", savedStudent.getCourse());
    }

    /**
     * Test of searchStudent method, of class student.
     */
    @Test
    public void testSearchStudent() {
       // Add a student to search for
        Scanner scanner = new Scanner("001\nJohn Doe\n18\njohn.doe@example.com\nComputer Science\n");
        student.saveStudent(scanner);

        // Search for the student
        scanner = new Scanner("001\n");
        student foundStudent = student.searchStudent(scanner);

        
        assertNotNull(foundStudent);
        assertEquals("001", foundStudent.getStudentID());
        assertEquals("John Doe", foundStudent.getName());
    }

    /**
     * Test of deleteStudent method, of class student.
     */
    @Test
    public void testDeleteStudent() {
        Scanner scanner = new Scanner("10111\n");
        boolean deleted = student.deleteStudent(scanner);
        
        assertFalse(deleted);
        assertEquals(0, student.students.size());
    }

    /**
     * Test of studentReport method, of class student.
     */
    @Test
    public void testStudentReport() {
        System.out.println("studentReport");
        student.studentReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayStudentInfo method, of class student.
     */
    @Test
    public void testDisplayStudentInfo() {
        System.out.println("displayStudentInfo");
        student instance = null;
        instance.displayStudentInfo(studentID);
        assertEquals(true, false);
    }

    /**
     * Test of exitApplication method, of class student.
     */
    @Test
    public void testExitApplication() {
        System.out.println("exitApplication");
        student.exitApplication();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
