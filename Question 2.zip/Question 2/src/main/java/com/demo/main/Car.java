/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.main;

import java.util.Scanner;

/**
 *
 * @author bonolodinkoanyane
 */
public class Car extends Vehicle {
    
   private int numberOfDoors;

    // Constructor for the car class
    public Car(String numberPlate, String make, String model, String colour, int numberOfDoors){
    // use this super to bring the parameters from the constructor from the super class to be ran in the sub class
        
    super(numberPlate, make, model, colour);
    this.numberOfDoors = numberOfDoors;
        
    } 
    
    public int getNumberOfDoors() {
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of doors on the vehicle: ");
        int numberOfDoors = scanner.nextInt();
        return numberOfDoors;
    }
    
         //this if statement below was taken from ChatGPT
        // on tuesday 02 September 2024
@Override
    public void displayInfo() {
        System.out.println("Car License Plate: " + registration() + "\n Make: " + model() + "\nModel: " + model() + 
                "\nColour " + colour() + "\nDoors: " + numberOfDoors + "\n Rented: " + (isRentedOut() ? "Yes" : "No"));
    }
}
   
        
    

