/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.demo.main;

/**
 *
 * @author bonolodinkoanyane
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RentalService rentalService = new RentalService();
        boolean running = true;

        while (running) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    addVehicleMenu(scanner, rentalService);
                    break;
                case 2:
                    rentalService.listVehicles();
                    break;
                case 3:
                    System.out.print("Enter Number Plate to earch: ");
                    String searchPlate = scanner.nextLine();
                    rentalService.searchForVehicle(searchPlate);
                    break;
                case 4:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid selection. Please select from list.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("1. Add Vehicle to Fleet");
        System.out.println("2. List All Vehicles");
        System.out.println("3. Search Vehicle by License Plate");
        System.out.println("4. Exit");
        System.out.print("Please enter your selection: ");
    }

    private static void addVehicleMenu(Scanner scanner, RentalService rentalService) {
        System.out.println("Select Vehicle Type to Add:");
        System.out.println("1. Car");
        System.out.println("2. Motorcycle");
        int vehicleType = scanner.nextInt();
        scanner.nextLine();  

        System.out.print("Enter Number Plate: ");
        String numberPlate = scanner.nextLine();
        System.out.print("Enter Make: ");
        String make = scanner.nextLine();
        System.out.print("Enter Model: ");
        String model = scanner.nextLine();
        System.out.print("Enter colour: ");
        String colour = scanner.nextLine();

        switch (vehicleType) {
            case 1 -> {
                System.out.print("Enter Number of Doors: ");
                var numberOfDoors = scanner.nextInt();
                scanner.nextLine();  
                rentalService.addVehicle(new Car(numberPlate, make, model, colour, numberOfDoors));
            }
            case 2 -> {
                System.out.print("Does it have a Sidecar? (true/false): ");
                boolean hasSidecar = scanner.nextBoolean();
                scanner.nextLine();  
                rentalService.addVehicle(new Motorcycle(numberPlate, make, model,colour, hasSidecar));
            }
            case 3 -> {
            
            }
            default -> System.out.println("Invalid vehicle type.");
        }
    }
}
