/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.main;

/**
 *
 * @author bonolodinkoanyane
 */

//motorcycle  constructor
public class Motorcycle extends Vehicle {
    
    private boolean hasSidecar;
    
    public Motorcycle(String numberPlate, String make, String model, String colour, boolean hasSidecar){
        
        super(numberPlate, make, model, colour);
        
    }
    
    public boolean hasSidecar() {
        return hasSidecar;
    }
    
    
//this if statement below was taken from ChatGPT
        // on tuesday 02 September 2024
    @Override
    public void displayInfo() {
        System.out.println("Motorcycle License Plate: " + registration() + "\nMake: " + make() + "\nModel: " + model() + "\nColour: "
                + colour() + "\nSidecar: " + (hasSidecar ? "Yes" : "No") + "\nRented: " + (isRentedOut() ? "Yes" : "No"));
    }
}

