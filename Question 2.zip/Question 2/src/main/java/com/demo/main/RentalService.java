/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.main;
import java.util.ArrayList;
/**
 *
 * @author bonolodinkoanyane
 */

public class RentalService {
    private ArrayList<Vehicle> fleet = new ArrayList<>();

   // This method allows the user to add the vehicles to the array
    public void addVehicle(Vehicle vehicle) {
        fleet.add(vehicle);
        System.out.println("Vehicle added to fleet successfully.");
    }

    // This method displays all the inventory in the array
    public void listVehicles() {
        if (fleet.isEmpty()) {
            System.out.println("No vehicles in the fleet.");
        } 
        else {
            for (Vehicle vehicle : fleet) {
                vehicle.displayInfo();
                System.out.println("----------------------------");
            }
        }
    }
    
    public void searchVehicle(String numberPlate) {
        Vehicle vehicle = findVehicleRegistration(numberPlate);
        if (vehicle != null) {
            if (!vehicle.isRentedOut()) {
                vehicle.rent();
                System.out.println("Vehicle " + numberPlate + " has been rented.");
            } 
            else {
                System.out.println("Vehicle " + numberPlate + " is already rented.");
            }
        } 
        else {
            System.out.println("Vehicle with license plate " + numberPlate + " not found.");
        }
    }

    public void searchforVehicle(String numberPlate) {
        Vehicle vehicle = findVehicleRegistration(numberPlate);
        if (vehicle != null) {
            System.out.println("Vehicle found:");
            vehicle.displayInfo();
        } 
        else {
            System.out.println("Vehicle with license plate " + numberPlate + " not found.");
        }
    }
    
    // Method to find a vehicle by license plate
    private Vehicle findVehicleRegistration(String licensePlate) {
        for (Vehicle vehicle : fleet) {
            if (vehicle.registration().equals(licensePlate)) {
                return vehicle;
            }
        }
        return null;
    
    }
}
