/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.demo.main;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author bonolodinkoanyane
 */
public abstract class Vehicle {
    
//general properties of a rental vehicle
    
    private String vehicleRegistration;
    private String make;
    private String model;
    private String colour;
    private boolean isRented;

    // Constructor
    public Vehicle(String numberPlate, String make, String model, String colour) {
        vehicleRegistration = numberPlate;
        this.make = make;
        this.model = model;
        this.colour = colour;
        isRented = false;  // Default is set to not rented because the cars are still on premises
    }
    
    //the methods below are the commen behaviours of different types of vehicles
    public String registration(){
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the vehicles registration: ");
        String registration = scanner.nextLine();
        return registration;
        
    }
    
    public String make(){
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the vehicle make: ");
        String make = scanner.nextLine();
        return make;
        
    }
    
    public String model(){
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the vehicle model: ");
        String model = scanner.nextLine();
        return model;
        
    }
    
    public String colour(){
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the vehicle colour: ");
        String colour = scanner.nextLine();
        
        return colour;
    }
    

    public boolean isRentedOut() {
        return isRented;
    } 
    
    public boolean rent() {
        this.isRented = true;
        return false;
    }
    
    public abstract void displayInfo();
}

    
    
