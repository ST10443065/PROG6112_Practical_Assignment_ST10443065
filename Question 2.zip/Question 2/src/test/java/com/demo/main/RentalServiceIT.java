/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.demo.main;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bonolodinkoanyane
 */
public class RentalServiceIT {
    
    public RentalServiceIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        
        RentalService RentalService = new RentalService();
        
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addVehicle method, of class RentalService.
     */
    @Test
    public void testAddCar() {
        Car car = new Car("ABC123", "Toyota", "Camry", "Blue", 4);
        RentalService.addVehicle(car);

        assertNotNull(RentalService.searchForVehicle("ABC123"));
        assertEquals("Toyota", car.make());
    }

    @Test
    public void testAddMotorcycle() {
        Motorcycle motorcycle = new Motorcycle("XYZ789", "BMW", "S1000rr", "Black", true);
        RentalService.addVehicle(motorcycle);

        assertNotNull(RentalService.searchForVehicle("XYZ789"));
        assertEquals("Harley", motorcycle.make());
    }

    /**
     * Test of listVehicles method, of class RentalService.
     */
    @Test
    public void testListVehicles() {
        System.out.println("listVehicles");
        RentalService instance = new RentalService();
        instance.listVehicles();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchVehicle method, of class RentalService.
     */
    @Test
public void testSearchVehicleFound() {
    Car car = new Car("DEF456", "Honda", "Civic", "Red", 4);
    RentalService.addVehicle(car);

    Vehicle foundVehicle = RentalService.searchForVehicle("DEF456");
    assertNotNull(foundVehicle);
    assertEquals("Honda", foundVehicle.make());
}

@Test
public void testSearchVehicleNotFound() {
    Vehicle foundVehicle = RentalService.searchForVehicle("NONEXISTENT");
    assertNull(foundVehicle);
}
    
}
